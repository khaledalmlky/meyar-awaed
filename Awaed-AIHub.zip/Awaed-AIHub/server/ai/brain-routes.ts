import type { Express, Request, Response } from "express";
import { processWithBrain, validateAnalysisRequired, getClientContext } from "./brain";
import { z } from "zod";
import { storage } from "../storage";

const brainRequestSchema = z.object({
  analysisId: z.number(),
  inputs: z.record(z.any()).optional(),
});

const guidedRequestSchema = z.object({
  inputs: z.object({
    businessType: z.string().min(1, "نوع النشاط مطلوب"),
    targetAudience: z.string().min(1, "الفئة المستهدفة مطلوبة"),
    goal: z.string().min(1, "الهدف مطلوب"),
    platforms: z.array(z.string()).min(1, "اختر منصة واحدة على الأقل"),
    budget: z.string().optional(),
    prompt: z.string().optional(),
    tone: z.string().optional(),
    contentType: z.string().optional(),
  }),
});

function requireAuth(req: Request, res: Response): string | null {
  const userId = req.session?.userId;
  if (!userId) {
    res.status(401).json({ error: "يجب تسجيل الدخول لاستخدام هذه الأداة." });
    return null;
  }
  return userId;
}

export function registerBrainRoutes(app: Express): void {
  app.get("/api/user/analyses", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const analyses = await storage.getLatestAnalysesPerUrl(userId);
      res.json(analyses);
    } catch (error) {
      console.error("Error fetching user analyses:", error);
      res.status(500).json({ error: "فشل في جلب التحليلات" });
    }
  });

  app.post("/api/brain/campaign", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const parsed = brainRequestSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({
          error: "بيانات غير صحيحة",
          details: parsed.error.errors,
        });
      }

      const validation = await validateAnalysisRequired(parsed.data.analysisId, userId);
      if (!validation.valid) {
        return res.status(400).json({
          error: validation.error,
          requiresAnalysis: true,
        });
      }

      const response = await processWithBrain({
        tool: 'campaign_brain',
        analysisId: parsed.data.analysisId,
        inputs: parsed.data.inputs || {},
        userId,
      });

      if (!response.success) {
        return res.status(500).json({ error: response.error });
      }

      res.json(response);
    } catch (error: any) {
      console.error("[Brain Campaign Error]", error);
      res.status(500).json({
        error: "حدث خطأ أثناء توليد الأفكار. يرجى المحاولة مرة أخرى.",
      });
    }
  });

  app.post("/api/brain/campaign-guided", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const parsed = guidedRequestSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({
          error: "يرجى تعبئة جميع الحقول المطلوبة: نوع النشاط، الفئة المستهدفة، الهدف، والمنصة",
          details: parsed.error.errors,
        });
      }

      const { inputs } = parsed.data;
      
      const response = await processWithBrain({
        tool: 'campaign_brain_guided',
        inputs: {
          ...inputs,
          isGuidedMode: true,
        },
        userId,
      });

      if (!response.success) {
        return res.status(500).json({ error: response.error });
      }

      res.json(response);
    } catch (error: any) {
      console.error("[Brain Campaign Guided Error]", error);
      res.status(500).json({
        error: "حدث خطأ أثناء توليد الأفكار. يرجى المحاولة مرة أخرى.",
      });
    }
  });

  app.post("/api/brain/content", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const parsed = brainRequestSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({
          error: "بيانات غير صحيحة",
          details: parsed.error.errors,
        });
      }

      const validation = await validateAnalysisRequired(parsed.data.analysisId, userId);
      if (!validation.valid) {
        return res.status(400).json({
          error: validation.error,
          requiresAnalysis: true,
        });
      }

      const response = await processWithBrain({
        tool: 'content_studio',
        analysisId: parsed.data.analysisId,
        inputs: parsed.data.inputs || {},
        userId,
      });

      if (!response.success) {
        return res.status(500).json({ error: response.error });
      }

      res.json(response);
    } catch (error: any) {
      console.error("[Brain Content Error]", error);
      res.status(500).json({
        error: "حدث خطأ أثناء توليد المحتوى. يرجى المحاولة مرة أخرى.",
      });
    }
  });

  // Content Studio - Guided Mode (without analysis)
  app.post("/api/brain/content-guided", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const parsed = guidedRequestSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({
          error: "يرجى تعبئة جميع الحقول المطلوبة",
          details: parsed.error.errors,
        });
      }

      const { inputs } = parsed.data;
      
      const response = await processWithBrain({
        tool: 'content_studio_guided',
        inputs: {
          ...inputs,
          isGuidedMode: true,
        },
        userId,
      });

      if (!response.success) {
        return res.status(500).json({ error: response.error });
      }

      res.json(response);
    } catch (error: any) {
      console.error("[Brain Content Guided Error]", error);
      res.status(500).json({
        error: "حدث خطأ أثناء توليد المحتوى. يرجى المحاولة مرة أخرى.",
      });
    }
  });

  app.post("/api/brain/planner", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const parsed = brainRequestSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({
          error: "بيانات غير صحيحة",
          details: parsed.error.errors,
        });
      }

      const validation = await validateAnalysisRequired(parsed.data.analysisId, userId);
      if (!validation.valid) {
        return res.status(400).json({
          error: validation.error,
          requiresAnalysis: true,
        });
      }

      const response = await processWithBrain({
        tool: 'campaign_planner',
        analysisId: parsed.data.analysisId,
        inputs: parsed.data.inputs || {},
        userId,
      });

      if (!response.success) {
        return res.status(500).json({ error: response.error });
      }

      res.json(response);
    } catch (error: any) {
      console.error("[Brain Planner Error]", error);
      res.status(500).json({
        error: "حدث خطأ أثناء تخطيط الحملة. يرجى المحاولة مرة أخرى.",
      });
    }
  });

  app.get("/api/brain/context/:analysisId", async (req: Request, res: Response) => {
    const userId = requireAuth(req, res);
    if (!userId) return;

    try {
      const analysisId = parseInt(req.params.analysisId);
      if (isNaN(analysisId)) {
        return res.status(400).json({ error: "معرف غير صالح" });
      }

      const validation = await validateAnalysisRequired(analysisId, userId);
      if (!validation.valid) {
        return res.status(404).json({ error: validation.error });
      }

      const context = await getClientContext(analysisId, userId);
      
      res.json({ success: true, context });
    } catch (error: any) {
      console.error("[Brain Context Error]", error);
      res.status(500).json({ error: "فشل في جلب السياق" });
    }
  });
}
