import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { registerAIRoutes } from "./ai/routes";
import { registerKnowledgeRoutes } from "./ai/knowledge-routes";
import { registerAnalyzerRoutes } from "./ai/analyzer-routes";
import { registerBrainRoutes } from "./ai/brain-routes";
import { registerPerformanceRoutes } from "./ai/performance-routes";
import { cleanupExpiredLogs, clearAllLogs, isLearningEnabled } from "./ai/learning";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  registerAIRoutes(app);
  registerKnowledgeRoutes(app);
  registerAnalyzerRoutes(app);
  registerBrainRoutes(app);
  registerPerformanceRoutes(app);

  // Admin-only learning control endpoints (internal use only)
  app.get("/api/admin/learning/status", async (req: Request, res: Response) => {
    const userId = req.session?.userId;
    if (!userId) {
      return res.status(401).json({ error: "غير مصرح" });
    }
    
    const user = await storage.getUser(userId);
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ error: "صلاحيات المدير مطلوبة" });
    }

    res.json({
      enabled: isLearningEnabled(),
      ttlDays: parseInt(process.env.LEARNING_TTL_DAYS || "90", 10),
    });
  });

  app.post("/api/admin/learning/cleanup", async (req: Request, res: Response) => {
    const userId = req.session?.userId;
    if (!userId) {
      return res.status(401).json({ error: "غير مصرح" });
    }
    
    const user = await storage.getUser(userId);
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ error: "صلاحيات المدير مطلوبة" });
    }

    const cleared = await cleanupExpiredLogs();
    res.json({ success: true, clearedCount: cleared });
  });

  app.post("/api/admin/learning/clear-all", async (req: Request, res: Response) => {
    const userId = req.session?.userId;
    if (!userId) {
      return res.status(401).json({ error: "غير مصرح" });
    }
    
    const user = await storage.getUser(userId);
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ error: "صلاحيات المدير مطلوبة" });
    }

    const cleared = await clearAllLogs();
    res.json({ success: true, clearedCount: cleared });
  });

  // Dashboard statistics endpoint
  app.get("/api/dashboard/stats", async (req: Request, res: Response) => {
    const userId = req.session?.userId;
    if (!userId) {
      return res.status(401).json({ error: "غير مصرح" });
    }

    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ error: "حدث خطأ في جلب الإحصائيات" });
    }
  });

  return httpServer;
}
